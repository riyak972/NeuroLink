document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".login-btn").addEventListener("click", function () {
        alert("Login button clicked!");
    });

    document.querySelector(".signup-btn").addEventListener("click", function () {
        alert("Signup button clicked!");
    });
});
