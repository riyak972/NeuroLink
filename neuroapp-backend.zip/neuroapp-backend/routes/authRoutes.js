const express = require("express");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const bcrypt = require("bcryptjs"); // For password hashing
const User = require("../models/User"); // Assuming you have a User model

dotenv.config();
const app = express();
app.use(express.json()); // Middleware to parse JSON

const SECRET_KEY = process.env.JWT_SECRET || "your-secret-key";

// Mock user data
const users = [{ email: "user@example.com", password: "yourpassword" }];

app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;

    // Find user
    const user = users.find((u) => u.email === email && u.password === password);
    if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
    }

    // Generate JWT token
    const token = jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: "1h" });

    res.json({ token });
});

// Start server
app.listen(3000, () => console.log("Server running on port 3000"));