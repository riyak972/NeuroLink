const express = require('express');
const authRoutes = require('./routes/authRoutes');  // your auth route file

const app = express();

// Middleware to parse incoming JSON request bodies
app.use(bodyParser.urlencoded({ extended: true }));  // This ensures that JSON requests are parsed
const bodyParser = require('body-parser');

// Add your routes here
app.use('/api/auth', authRoutes);

// Your other routes and server configuration
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

app.use((req, res, next) => {
    console.log('Request Body:', req.body);  // Add this line to debug the body
    next();
  });


