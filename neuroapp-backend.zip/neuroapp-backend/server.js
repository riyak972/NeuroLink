// Import required modules
const express = require('express');
const bodyParser = require('body-parser');

// Create an instance of express
const app = express();

// Set the port for the server
const PORT = process.env.PORT || 3000;
require('dotenv').config(); // Load environment variables from .env file
// Middleware to parse incoming request bodies
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Sample route
app.get('/', (req, res) => {
    res.send('Welcome to NeuroLink Backend!');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

// Mock user data for login (you will replace this with a database later)
const mockUser = {
    email: 'user@example.com',
    password: 'password123'
};

// Login API
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    if (email === mockUser.email && password === mockUser.password) {
        res.status(200).json({ message: 'Login successful!' });
    } else {
        res.status(401).json({ message: 'Invalid credentials' });
    }
});
